# ÌLÉ ÀṢẸ́ IFÁ AWOPEJU — versión LITE (sin audios pesados)

Esta versión está optimizada para **GitHub Pages**: excluye archivos de audio grandes.
Puedes subir **solo pistas ligeras** (ideal < 10–15 MB) en `assets/audio/` y controlar cuáles usar con `assets/audio/playlist.json`.

## Publicación
1. Sube todo este contenido a un repositorio público.
2. En *Settings → Pages*: Source = `main`, Folder = `/ (root)` → **Save**.
3. Abre la URL que te ofrece GitHub.

## Añadir audio (ligero)
1. Copia tus `.mp3` livianos en `assets/audio/`.
2. Opcional: edita `assets/audio/playlist.json` con los nombres exactos de archivo.
3. ¡Listo! El motor busca primero en `playlist.json` y si no, intenta por nombre.

> Consejo: Si necesitas audios más pesados, usa **Git LFS** o comprímelos a ~128 kbps.

## Créditos
Diseño y desarrollo: Ìṣẹ̀ṣẹ̀ tradicional, blanco + dorado, auras por Òrìṣà, motor de audio por sección (fade in/out).
