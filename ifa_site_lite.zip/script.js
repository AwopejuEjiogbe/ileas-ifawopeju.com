// --- Audio engine (lite) ---
// Este motor evita archivos pesados en GitHub. Carga sólo lo que el usuario incluya en assets/audio.
// Si un archivo no existe o el navegador bloquea autoplay móvil, no rompe la página.

const SECTION_TO_KEYS = {
  inicio: ["intro"],
  esu: ["esu"],
  ogun: ["ogun"],
  oshosi: ["oshosi"],
  obatala: ["obatala"],
  sango: ["sango"],
  yemoja: ["yemoja","yemoya","iyemoya","iyemoja"],
  oya: ["oya","oyá"],
  osun: ["osun","oshun","ọ̀ṣun","osún"],
  orunmila: ["orunmila","òrúnmìlá"],
  ifa: ["ifa","ifá"],
  egungun: ["egungun","egúngún"],
  olodumare: ["olodumare","olódùmarè"]
};

// Reglas por palabras clave en nombre de archivo (minúsculas)
const PLAYLIST_KEYWORDS = {
  intro: ["intro","ifayomi"],
  esu: ["esu","elegba","elegua"], // se ignora la reinterpretación, pero ayuda a capturar nombres de archivo
  ogun: ["ogun"],
  oshosi: ["oshosi","ososi","oshossi"],
  obatala: ["obatala","obbatala","obàtálá","obatala"],
  sango: ["sango","shango","ṣàngó"],
  yemoja: ["yemoja","yemaya","yemọja","yèyemọja"],
  oya: ["oya","ọ̀yá"],
  osun: ["osun","oshun","ọ̀ṣun"],
  orunmila: ["orunmila","òrúnmìlá"],
  ifa: ["ifa","ifá"],
  egungun: ["egungun","ẹgẹngun"],
  olodumare: ["olodumare","olódùmarè"]
};

// Config
const AUDIO_PATH = "assets/audio/";
const FADE_MS = 900;

// Estado
let audio = new Audio();
audio.preload = "auto";
audio.volume = 0;
let currentKey = null;
let userActivated = false;

// Botón para desbloquear audio en móvil
const toggleBtn = document.getElementById("audioToggle");
toggleBtn.addEventListener("click", async () => {
  userActivated = true;
  toggleBtn.classList.toggle("on");
  const pressed = toggleBtn.getAttribute("aria-pressed") === "true";
  toggleBtn.setAttribute("aria-pressed", String(!pressed));
  if (!pressed) {
    // arrancar con la sección visible
    const active = getMostVisibleSectionId();
    if (active) {
      playForSection(active);
    }
    toggleBtn.textContent = "⏸️ Pausar sonido";
  } else {
    fadeOut(audio, FADE_MS);
    toggleBtn.textContent = "🔊 Activar sonido";
  }
});

// Observador de secciones
const sections = [...document.querySelectorAll("main.section, section.section")];
const io = new IntersectionObserver((entries)=>{
  // elegir la sección con mayor intersección
  const top = entries.filter(e=>e.isIntersecting).sort((a,b)=>b.intersectionRatio - a.intersectionRatio)[0];
  if(!top) return;
  const id = top.target.id || "inicio";
  if (!userActivated) return; // esperar interacción
  playForSection(id);
},{threshold:[0.55,0.75]});

sections.forEach(s=>io.observe(s));

function getMostVisibleSectionId(){
  let best = null; let ratio = 0;
  sections.forEach(sec=>{
    const r = sec.getBoundingClientRect();
    const vis = Math.max(0, Math.min(window.innerHeight, r.bottom) - Math.max(0, r.top));
    const score = vis / Math.max(1, r.height);
    if (score > ratio){ ratio = score; best = sec.id; }
  });
  return best;
}

function pickFileForKey(key){
  // Busca archivos en carpeta por heurística de nombre. No podemos listar el directorio;
  // usamos una lista sugerida que el usuario colocará en playlist.json si quiere control fino.
  // Intento 1: playlist.json
  // Intento 2: nombres comunes (si el usuario renombra los archivos).
  return fetch(AUDIO_PATH + "playlist.json", {cache:"no-store"})
    .then(r => r.ok ? r.json() : Promise.resolve({}))
    .then(list => {
      const candidates = (list[key] || []).map(s => AUDIO_PATH + s);
      if (candidates.length) return tryFirstExisting(candidates);
      // fallback a heurística
      const heuristics = (list._all || []).length ? list._all : [
        // el usuario puede rellenar _all para acelerar; si no, probamos nombres comunes
        "Asabioje_Afenapa_-_Ifa.mp3",
        "Adedayo_Ologundudu_-_Esu.mp3",
        "Adedayo_Ologundudu_-_Ogun.mp3",
        "Adedayo_Ologundudu_-_Oshosi.mp3",
        "Adedayo_Ologundudu_-_Obatala.mp3",
        "Asabioje_Afenapa_-_Sango.mp3",
        "Asabioje_Afenapa_-_Yemoja.mp3",
        "Asabioje_Afenapa_-_Oya.mp3",
        "Asabioje_Afenapa_-_Osun.mp3",
        "Hondread_-_Intro.mp3",
        "Egungun_Dancing_with_Bata_Drums.mp3"
      ];
      const keyWords = (PLAYLIST_KEYWORDS[key] || []);
      const filtered = heuristics.filter(n => keyWords.some(w => n.toLowerCase().includes(w)));
      const paths = filtered.map(s => AUDIO_PATH + s);
      return tryFirstExisting(paths);
    });
}

function tryFirstExisting(paths){
  // Probar en cadena hasta que uno exista (HEAD)
  let idx = 0;
  return new Promise((resolve) => {
    const next = () => {
      if (idx >= paths.length) return resolve(null);
      const url = paths[idx++];
      fetch(url, {method:"HEAD"}).then(r=>{
        if (r.ok) resolve(url); else next();
      }).catch(()=> next());
    };
    next();
  });
}

let fadeTimer = null;
function fadeTo(targetVol, ms){
  if (fadeTimer) { clearInterval(fadeTimer); fadeTimer = null; }
  const steps = Math.max(1, Math.floor(ms/30));
  const start = audio.volume;
  let i=0;
  fadeTimer = setInterval(()=>{
    i++;
    const v = start + (targetVol - start) * (i/steps);
    audio.volume = Math.max(0, Math.min(1, v));
    if (i>=steps){ clearInterval(fadeTimer); fadeTimer=null; }
  }, 30);
}

function fadeOut(aud, ms){ fadeTo(0, ms); }

async function playForSection(sectionId){
  const keys = SECTION_TO_KEYS[sectionId] || [sectionId];
  const key = keys[0];
  if (currentKey === key) return;
  const fileUrl = await pickFileForKey(key);
  if (!fileUrl){
    currentKey = key;
    // silencio elegante
    fadeOut(audio, FADE_MS);
    return;
  }
  currentKey = key;
  try {
    const wasPlaying = !audio.paused;
    fadeOut(audio, FADE_MS);
    setTimeout(()=>{
      audio.src = fileUrl;
      audio.loop = true;
      audio.play().then(()=>{
        fadeTo(0.7, FADE_MS);
      }).catch(()=>{/* bloqueado por user gesture; esperar */});
    }, FADE_MS + 50);
  } catch(e){
    console.warn("No se pudo reproducir:", e);
  }
}
